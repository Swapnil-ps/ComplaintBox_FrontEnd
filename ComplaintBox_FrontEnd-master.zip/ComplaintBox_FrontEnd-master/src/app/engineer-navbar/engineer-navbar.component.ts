import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engineer-navbar',
  templateUrl: './engineer-navbar.component.html',
  styleUrls: ['./engineer-navbar.component.css']
})
export class EngineerNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
