export interface Register{
    username: any
	password:any
	role:any
}