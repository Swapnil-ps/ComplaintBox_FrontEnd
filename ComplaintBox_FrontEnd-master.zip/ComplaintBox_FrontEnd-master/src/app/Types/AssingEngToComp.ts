export interface AssingEngToComp {
    engineerId: any;
    complaintId: any;
}