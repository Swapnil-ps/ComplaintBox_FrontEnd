export interface Customer {
    cust_id:any;
    name: String;
    address: String;
    pinCode: String;
    contact: number;
    ticket: String;
}