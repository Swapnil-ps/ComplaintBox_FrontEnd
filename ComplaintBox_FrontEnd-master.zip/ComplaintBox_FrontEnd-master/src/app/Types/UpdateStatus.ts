export interface updateStatus {
    complaintId: any;
    status: any;

}
