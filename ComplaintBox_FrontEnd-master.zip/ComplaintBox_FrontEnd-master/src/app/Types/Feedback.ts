export interface Feedback{
    complaintId: any;
    feedback: any;
}