export interface Manager{
    manager_id: any;
    name: String;
	pinCode: String;
}